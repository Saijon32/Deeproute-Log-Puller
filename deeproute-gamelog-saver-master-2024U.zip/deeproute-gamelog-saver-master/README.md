# Description
A chrome extension that allows players to download the game logs for the DeepRoute.com football game.

# Usage
1. Download the zip file: https://github.com/GridironApps/deeproute-gamelog-saver/archive/refs/heads/master.zip
2. Unpack the file
3. Follow the instructions to load an unpacked extension using developer mode: https://developer.chrome.com/extensions/getstarted#manifest
